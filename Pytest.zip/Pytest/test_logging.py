#Through logging class we can create a object and user logging class method getLogger
#FileHandler("logFile.log") method is used to pass log file where we have to write a log
import logging

def test_logging():

    logger = logging.getLogger(__name__)  # here we are passing test file name through (__name__)

    fileHandler = logging.FileHandler('logFile.log')

    formatter = logging.Formatter("%(asctime)s :%(levelname)s : %(name)s :%(message)s")  # set a format

    fileHandler.setFormatter(formatter)

    logger.addHandler(fileHandler)  # Pass fileHandler object so we can write our log into logFile.log file

    logger.setLevel(logging.DEBUG)  # Set the level so accordingly you can print the logs

    logger.debug("Debug statement is executed")

    logger.info("log statement is executed")

    logger.warning("warning statement is executed")

    logger.error("error statement is executed")

    logger.critical("critical statement is executed")