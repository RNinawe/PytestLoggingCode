import inspect
import logging

class loggerClass:


    def getLogger(self):

        loggerName = inspect.stack()[1][3]

        logger = logging.getLogger(loggerName)  # here we are passing test file name through (__name__)

        fileHandler = logging.FileHandler('logFile.log')

        formatter = logging.Formatter("%(asctime)s :%(levelname)s : %(name)s :%(message)s")  # set a format

        fileHandler.setFormatter(formatter)

        logger.addHandler(fileHandler)  # Pass fileHandler object so we can write our log into logFile.log file

        logger.setLevel(logging.INFO)  # Set the level so accordingly you can print the logs

        return  logger
