

import pytest

from Pytest.conftest import crossBrowser
from Pytest.loggerClass import loggerClass


@pytest.mark.usefixtures("setup") #Adding fixture globally to all methods of class TestExample
class TestExample:

    def test_fixtureDemo1(self):
        print("i will execute steps in FixtureDemo method")

    def test_fixtureDemo2(self):
        print("i will execute steps in FixtureDemo method")

    def test_fixtureDemo3(self):
        print("i will execute steps in FixtureDemo method")

    def test_fixtureDemo4(self):
        print("i will execute steps in FixtureDemo method")

    def test_fixtureDemo5(self):
        print("i will execute steps in FixtureDemo method")

#This fixture is used to pass values during run and print all the values
@pytest.mark.usefixtures("dataLoad")
class TestExample2(loggerClass):

    def test_editProfile(self, dataLoad):
        log = self.getLogger()
        log.info(dataLoad[0])
        log.info(dataLoad[2])
        print(dataLoad[2])

#Here crossbrowser fixture is used to pass parameter in every run
    def test_crossBrowser(self,crossBrowser):
        print("I am printing crossBrowser values")
        print(crossBrowser[2])

