


import pytest

@pytest.mark.smoke #This is used to test as part of smoke testing
@pytest.mark.skip #This is used to skip the test
def test_firstProgram():
    print("First program result")

def test_secondProgram(setup): #here we have define fixture setup to run as pre-requiste test
    print("Second Program result")

@pytest.mark.xfail #This is usedd to run but it will pass
def test_thridProgram():
    print("Third Program result")

