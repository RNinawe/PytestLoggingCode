import pytest

from Pytest.loggerClass import loggerClass


@pytest.mark.usefixtures("dataLoad")
class TestExample2(loggerClass):

    def test_editProfile(self, dataLoad):
        log = self.getLogger()
        log.info(dataLoad[0])
        log.info(dataLoad[2])
        print(dataLoad[2])




