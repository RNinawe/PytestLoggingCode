import pytest


@pytest.fixture()
# @pytest.fixture(scope='class') # here we are define the scope of the fixture execution,
# now fixture will only execute in class level and only will executed once class is executed
def setup():
    print("i will be executing First")
    yield
    print("I will execute last")

#This fixture is used to pass all the values during run time and prints all wherever its calling
@pytest.fixture()
def dataLoad():
    print("user profile data is being created")
    return ["Rashmi", "Ninawe", "rashmininawe1987@gmail.com"]

#This is a parametrized  fixtures, which is used to pass parameter to fixture method in each run
@pytest.fixture(params=[("chrom","Prateek","rashmi"),("Firefox","prateek.k89","ninawerashi.7"),("IE","32","32")])
def crossBrowser(request):
    return request.param
