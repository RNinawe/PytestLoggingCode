#Any pytest file should start with test_ or end with _test
#pytest method names should start with test_
#Any code should wrap in method only
#If you have same method name in same pytest file, result will be overwrite
#Method name should be meaning ful because Test case name same as method name
#-k stand for mthod name execution.-s for logs in out put -v stands for more info metadata
#You can run specific file with py.test <filename>
#You can create a group to run some selected test cases by @pytest.mark.givename
#you can mark (tag) tests @pytest.mark.smoke and then run with -m
#e.g py.test - m smoke -v -s
#Skip the test by mark (tag) tests @pytest.mark.skip and then run with as py.test -v -s
#if you have to few some test case which have to tun as pre-requisite test use , mark (tag) @pytest.mark.xfail

#fixture are used a setup and tear down for test cases- conftest file is generaloize

#fixture and make it available to all test cases(fixture name into parameters of method)

#datadriven and parameterization can be done with return statements in list format

#when you define fixture scope to class only, it will run once before class is initiated and at teh end

#Fixtures are used as setup and tear down methods for test cases
#Conftest file to generalize fixtureand make it avaiable to the test cases
#Fixtures is used to set Before and After run, so accordinly test sequence can mantained
#Use @pytest.fixture() for before
#for to create dependency on fixtures test case,pass that function name with other test case
# e.g: test_fixtureDemo(setup), setup is the before method fixture
#yield keyword is use to define run at the end of the execution

#If you want to set any fixture Globally to all the method unser that class set as below:-
#e.g @pytest.mark.usefixtures("setup")

#@pytest.fixture(scope='class') # here we are define the scope of the fixture execution,
# now fixture will only execute in class level and only will executed once class is executed


#**********************How to install pytest and others commands******************
#Open cmd command and type below cmds
#pip install pytest , this command is used to install pytest in our system
#pip install pytest-html , this is used to install pyest-html

#*******************************Pytest commands*****************************
#py.test
#py.test -v -s
#py.test -m markname -v -s
#py.test pytestFileName.py -v -s


#*******************************Pytest html commands*****************************
#pip install pytest-html , this is used to install pytest-html
#py.test --html=report.html , this command is used to display the resul in html format

#********************************Logging Error**************************************
#Log are below type

#Debug
#Info
#error
#warning
#critical

#e.g logs.warning()

#e.g 2019-02-17 12:40:14,789 :ERROR "<testcasename> fatel errir in submitting credit card payment on step4.cant continue

