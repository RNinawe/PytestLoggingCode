def test_firstProgram():
    a=10
    if a==10:
        print("a is equal to 10")
    else:
        print("a is not equal to 10")

    assert a == 11,"a is not equal to 10"


def test_secondProgram():
    a=12
    b=10
    if a==b:
        print("a is equal to b")
    else:
        print("a is not equal to b")

    assert a == b,"a is not equal to b"